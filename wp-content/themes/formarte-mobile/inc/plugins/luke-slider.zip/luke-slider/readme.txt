=== Luke Slider ===
Contributors: lukepostulka
Tags: plugin, wordpress, slider
Requires at least: 3.8
Tested up to: 4.3.1
Stable tag: 1.0
License: GPLv2 or later  
License URI: http://www.gnu.org/licenses/gpl-2.0.html 


==Description==

Luke Slider is a lightweight plugin that will provide your theme with slider which you can easily customize in your WordPress dashboard. You can provide your slider with title, short description and button with link. If you don't provide any of those in your WP admin dashboard slider will show only images.


==Changelog==

= 1.0 =
*Release Date - 20th September, 2015*
* Published version


==Credits==

Owl Carousel