jQuery(document).ready(function($) {
	jQuery("#main-home-slider").owlCarousel({   
      
      slideSpeed : 700,
      paginationSpeed : 700,
      rewindSpeed : 1500,
      singleItem : true,
      pagination : false,
      lazyLoad : true,
      autoPlay : 10000,
      stopOnHover : true,
      navigation: false
   });  

});
